# TALLER #2 - ALGORITMOS (Ejercicios 1 al 10)
# Autor: BRAYAN SNEYDER GARCIA CAMACHO

def ejercicio1_definicion():
    # EJERCICIO 1 - Definicion y caracteristicas
    print("EJERCICIO 1 - DEFINICION DE ALGORITMO\n")
    print("Un algoritmo es un conjunto ordenado y finito de pasos que resuelve un problema.")
    print("Caracteristicas: 1) Finitud, 2) Precision, 3) Entrada/Salida\n")

def ejercicio2_precio_iva():
    # EJERCICIO 2 - Entrada: precio_base; Proceso: calcular IVA y precio_final; Salida: precio_final
    try:
        precio_base = float(input("Ingrese el precio base (sin IVA): ").strip())
    except ValueError:
        print("ERROR: Debe ingresar un numero valido.")
        return
    if precio_base < 0:
        print("ERROR: El precio no puede ser negativo.")
        return
    iva = precio_base * 0.19  # calcular IVA 19%
    precio_final = precio_base + iva
    print(f"Precio base: {precio_base:.2f}")
    print(f"IVA (19%): {iva:.2f}")
    print(f"Precio final (con IVA): {precio_final:.2f}\n")

def ejercicio3_celsius_fahrenheit():
    # EJERCICIO 3 - Convertir Celsius a Fahrenheit
    try:
        c = float(input("Ingrese la temperatura en grados Celsius: ").strip())
    except ValueError:
        print("ERROR: Debe ingresar un numero valido.")
        return
    f = (c * 9/5) + 32
    print(f"Temperatura en Fahrenheit: {f:.2f}\n")

def ejercicio4_aprobado_reprobado():
    # EJERCICIO 4 - Leer calificacion y determinar aprobado o reprobado
    try:
        nota = float(input("Ingrese la nota del estudiante (0 a 10): ").strip())
    except ValueError:
        print("ERROR: Nota invalida.")
        return
    if nota < 0 or nota > 10:
        print("ERROR: Nota fuera de rango (0-10).")
        return
    if nota >= 6:
        print("Aprobado\n")
    else:
        print("Reprobado\n")

def ejercicio5_pseudocodigo_ingles():
    # EJERCICIO 5 - Version en pseudocodigo en ingles (simulado en consola)
    print("EJERCICIO 5 - Pseudocodigo (read/write/if-then-else):")
    print("write 'Ingrese la nota del estudiante (0-10):'")
    print("read nota")
    print("if nota < 0 or nota > 10 then")
    print("    write 'ERROR: Nota invalida.'")
    print("else")
    print("    if nota >= 6 then")
    print("        write 'Aprobado'")
    print("    else")
    print("        write 'Reprobado'")
    print("    end")
    print("end\n")

def ejercicio6_suma_numeros_n():
    # EJERCICIO 6 - Suma de los primeros N enteros usando ciclo while (contador y acumulador)
    try:
        n = int(input("Ingrese N (numero de primeros enteros a sumar): ").strip())
    except ValueError:
        print("ERROR: Debe ingresar un entero valido.")
        return
    if n < 1:
        print("ERROR: N debe ser >= 1.")
        return
    contador = 1
    suma = 0
    while contador <= n:
        suma += contador  # acumular el valor actual del contador
        contador += 1     # incrementar el contador
    print(f"La suma de los primeros {n} numeros es: {suma}\n")

def ejercicio7_contar_pos_neg():
    # EJERCICIO 7 - Leer N numeros y contar cuantos son positivos y negativos
    try:
        n = int(input("Ingrese la cantidad de numeros a evaluar (N): ").strip())
    except ValueError:
        print("ERROR: Debe ingresar un entero valido.")
        return
    if n <= 0:
        print("ERROR: N debe ser mayor que 0.")
        return
    positivos = 0
    negativos = 0
    for i in range(1, n+1):
        try:
            num = float(input(f"Ingrese el numero {i}: ").strip())
        except ValueError:
            print("Entrada invalida, se considera 0.")
            num = 0
        if num > 0:
            positivos += 1
        elif num < 0:
            negativos += 1
    print(f"Positivos: {positivos}")
    print(f"Negativos: {negativos}\n")

def ejercicio8_top_down_registro_venta():
    # EJERCICIO 8 - Diseño descendente: describir modulos principales
    print("EJERCICIO 8 - Registro de Venta (Top-Down)")
    print("Modulo principal: RegistroVenta()")
    print("Submodulos:")
    print(" 1) RegistrarProductoVenta(codigo, cantidad, precio_unitario)")
    print(" 2) CalcularTotalVenta(lista_items) -> subtotal, impuestos, total")
    print(" 3) GenerarRecibo(venta) -> imprimir detalle y total\n")

def ejercicio9_promedio_3_calificaciones():
    # EJERCICIO 9 - Promedio de 3 calificaciones (refinado)
    try:
        n1 = float(input("Ingrese la primera nota: ").strip())
        n2 = float(input("Ingrese la segunda nota: ").strip())
        n3 = float(input("Ingrese la tercera nota: ").strip())
    except ValueError:
        print("ERROR: Nota invalida.")
        return
    promedio = (n1 + n2 + n3) / 3
    print(f"El promedio de las 3 notas es: {promedio:.2f}\n")

def ejercicio10_diagrama_flujo_instrucciones():
    # EJERCICIO 10 - Instrucciones para crear diagrama de flujo
    print("EJERCICIO 10 - Diagrama de flujo para Ejercicio 4 (Aprobado/Reprobado)")
    print("Usar simbolos: Inicio/Fin (oval), Entrada/Salida (paralelogramo), Proceso (rectangulo), Decisión (rombo).")
    print("Flujo: Inicio -> Entrada: nota -> Decision: nota>=6? -> Si: escribir 'Aprobado' -> Fin")
    print("                                 -> No: escribir 'Reprobado' -> Fin\n")

# Menu interactivo para probar cada ejercicio (opcional)
def menu():
    while True:
        print("TALLER #2 - EJERCICIOS (1-10)")
        print("1-10: Ejecutar ejercicio correspondiente, 0: Salir")
        opc = input("Ingrese ejercicio (0-10): ").strip()
        if opc == "0":
            break
        if opc == "1":
            ejercicio1_definicion()
        elif opc == "2":
            ejercicio2_precio_iva()
        elif opc == "3":
            ejercicio3_celsius_fahrenheit()
        elif opc == "4":
            ejercicio4_aprobado_reprobado()
        elif opc == "5":
            ejercicio5_pseudocodigo_ingles()
        elif opc == "6":
            ejercicio6_suma_numeros_n()
        elif opc == "7":
            ejercicio7_contar_pos_neg()
        elif opc == "8":
            ejercicio8_top_down_registro_venta()
        elif opc == "9":
            ejercicio9_promedio_3_calificaciones()
        elif opc == "10":
            ejercicio10_diagrama_flujo_instrucciones()
        else:
            print("Opcion invalida.")
        input("Presione Enter para continuar...")

if __name__ == '__main__':
    menu()
